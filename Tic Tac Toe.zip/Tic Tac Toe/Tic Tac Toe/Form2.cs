﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class Form2 : Form
    {
        // Khai báo các biến
        Image AnhO;
        Image AnhX;
        int anh = 1;
        public Form2()
        {
            InitializeComponent();
            // Tạo bàn cờ và gán các ảnh vào các biến
            VeBanCo();
            TaoAnh();
        }

        // Tạo ma trận để theo dõi
        private List<List<Button>> matrix;
        public List<List<Button>> Matrix
        {
            get => matrix; 
            set => matrix = value;
        }

        // Hàm tạo ảnh
        public void TaoAnh() {
            // Gán các ảnh từ trong file vào các biến
            AnhO = Image.FromFile(Application.StartupPath + "\\Resources\\O.png");
            AnhX = Image.FromFile(Application.StartupPath + "\\Resources\\X.png");
            pictureBox1.BackgroundImage = AnhO;
        }

        // Hàm tạo bàn cờ
        void VeBanCo()
        {
            BanCo.Enabled = true;
            BanCo.Controls.Clear();

            Matrix = new List<List<Button>>();
            // Tạo ma trận các nút 20x20

            Button oldButton = new Button()
            {
                Width = 0,
                Location = new Point(0, 0)
            };

            for (int i = 0; i < 20; i++) {
                Matrix.Add(new List<Button>());
                for (int j = 0; j < 20; j++)
                {
                    Button btn = new Button() {
                        Width = 30,
                        Height = 30,
                        Location = new Point(oldButton.Location.X + 30, oldButton.Location.Y),
                        BackgroundImageLayout = ImageLayout.Stretch,
                        Tag = i.ToString()
                    };
                    BanCo.Controls.Add(btn);
                    btn.Click += btn_click;
                    Matrix[i].Add(btn);

                    oldButton = btn;
                }
                oldButton.Location = new Point(0, oldButton.Location.Y + 30);

                oldButton.Width = 0;
                oldButton.Height = 0;
            }
        }

        // Hàm sự kiện khi bấm nút
        private void btn_click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            // Kiểm tra nút đã dùng chưa
            if (btn.BackgroundImage != null)
            {
                return;
            }
            if (anh == 1)
            {
                // Gán ảnh nền của nút bằng ảnh X
                pictureBox1.BackgroundImage = AnhX;
                btn.BackgroundImage = AnhO;
                anh = 0;
            } 
            else
            {
                // Gán ảnh nền của nút bằng ảnh O
                pictureBox1.BackgroundImage = AnhO;
                btn.BackgroundImage = AnhX;
                anh = 1;
            }
            // Kiểm tra thắng thua
            if (ThangThua(btn))
            {
                // Kết thúc trận đấu
                EndGame();
            }
        }

        // Hàm kết thúc trận đấu
        private void EndGame()
        {
            MessageBox.Show("Game Over!");
            // Tạo lại form ban đầu và đóng form này
            Form Form1 = new Form1();
            Form1.Show();
            this.Close();
        }

        // Hàm kiểm tra thắng thua
        private bool ThangThua(Button btn) { 
            return EndGameDoc(btn) || EndGameNgang(btn) || EndGameCheoChinh(btn) || EndGameCheoPhu(btn) || HetODanh(btn);
        }

        // Hàm xác định tọa độ nút được ấn
        private Point XacDinhToaDo(Button btn)
        {
            // Gán tọa độ nút 
            int doc = Convert.ToInt32(btn.Tag);
            int ngang = Matrix[doc].IndexOf(btn);
            Point point = new Point(ngang, doc);
            return point;
        }

        // Kiểm tra thắng thua theo hàng dọc
        private bool EndGameDoc(Button btn)
        {
            // Xác định tọa độ
            Point point = XacDinhToaDo(btn);
            // Khai báo các biến đếm
            int tren = 0;
            int duoi = 0;
            // Đếm các giá trị giống nhau
            for (int i = point.X; i >= 0; i--)
            {
                if (Matrix[point.Y][i].BackgroundImage == btn.BackgroundImage)
                {
                    tren++;
                } else { 
                    break;
                }
            }

            for (int i = point.X + 1; i < 20; i++)
            {
                if (Matrix[point.Y][i].BackgroundImage == btn.BackgroundImage)
                {
                    duoi++;
                } else {  
                    break; 
                }
            }
            // Kiểm tra thỏa mãn điều kiện
            return tren + duoi == 5; 
        }

        // Kiểm tra thắng thua theo hàng ngang
        private bool EndGameNgang(Button btn)
        {
            // Xác định tọa độ
            Point point = XacDinhToaDo(btn);
            int trai = 0;
            int phai = 0;
            // Đếm các giá trị giống nhau
            for (int i = point.Y; i >= 0; i--)
            {
                if (Matrix[i][point.X].BackgroundImage == btn.BackgroundImage)
                {
                    trai++;
                }
                else
                {
                    break;
                }
            }

            for (int i = point.Y + 1; i < 20; i++)
            {
                if (Matrix[i][point.X].BackgroundImage == btn.BackgroundImage)
                {
                    phai++;
                }
                else
                {
                    break;
                }
            }
            // Kiểm tra thỏa mãn điều kiện
            return trai + phai == 5;
        }

        // Kiểm tra thắng thua theo đường chéo chính
        private bool EndGameCheoChinh(Button btn) {
            // Xác định tọa độ
            Point point = XacDinhToaDo(btn);
            // Khai báo các biến đếm
            int tren = 0;
            int duoi = 0;
            // Đếm các giá trị giống nhau
            for (int i = 0; i <= point.X; i++)
            {
                if (point.X - i < 0 || point.Y - i < 0) {
                    break;
                }
                if (Matrix[point.Y - i][point.X - i].BackgroundImage == btn.BackgroundImage) { 
                tren++;
                }
            }

            for (int i = 1; i <= 20 - point.X; i++)
            {
                if (point.X + i >= 20 || point.Y + i >= 20)
                {
                    break;
                }
                if (Matrix[point.Y + i][point.X + i].BackgroundImage == btn.BackgroundImage)
                {
                    duoi++;
                }
            }
            // Kiểm tra thỏa mãn điều kiện
            return tren + duoi == 5;
        }

        // Kiểm tra thắng thua theo đường chéo phụ
        private bool EndGameCheoPhu(Button btn)
        {
            // Xác định tọa độ
            Point point = XacDinhToaDo(btn);
            // Khai báo các biến đếm
            int tren = 0;
            int duoi = 0;
            // Đếm các giá trị giống nhau
            for (int i = 0; i <= point.X; i++)
            {
                if (point.X + i >= 20 || point.Y - i < 0)
                {
                    break;
                }
                if (Matrix[point.Y - i][point.X + i].BackgroundImage == btn.BackgroundImage)
                {
                    tren++;
                }
            }

            for (int i = 1; i <= 20 - point.X; i++)
            {
                if (point.X - i < 0 || point.Y + i >= 20)
                {
                    break;
                }
                if (Matrix[point.Y + i][point.X - i].BackgroundImage == btn.BackgroundImage)
                {
                    duoi++;
                }
            }
            // Kiểm tra thỏa mãn điều kiện
            return tren + duoi == 5;
        }

        // Kiểm tra hết ô đánh
        private bool HetODanh(Button btn)
        {
            // Xét lần lượt các ô
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    // Kiểm tra các nút đã dùng hay chưa
                    if (Matrix[i][j].BackgroundImage == null)
                    { 
                        return false;
                    }
                }
            }
            return true;
        }

    }
}
