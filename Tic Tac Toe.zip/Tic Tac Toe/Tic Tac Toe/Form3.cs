﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Tic_Tac_Toe
{
    public partial class Form3 : Form
    {
        // Khai báo các biến
        private Button[,] buttons;
        private char[,] board;
        private char currentPlayer;
        Image AnhO;
        Image AnhX;
        int hang;
        int cot;
        public Form3()
        {
            InitializeComponent();
            // Tạo bàn cờ và gán các ảnh vào các biến
            TaoBanCo();
            TaoAnh();
        }

        // Hàm tạo bàn cờ
        private void TaoBanCo()
        {
            // Tạo ma trận các nút 3x3
            buttons = new Button[3, 3]
            {
                { button00, button01, button02 },
                { button10, button11, button12 },
                { button20, button21, button22 }
            };
            // Tạo bảng 3x3 để theo dõi
            board = new char[3, 3];
            // Người chơi đầu là X
            currentPlayer = 'X';
            // Đặt giá trị ban đầu của bảng theo dõi
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Giá trị ban đầu của các ô trong bảng là rỗng 
                    board[i, j] = '\0';
                    buttons[i, j].BackgroundImageLayout = ImageLayout.Stretch;
                    buttons[i, j].Click += Button_Click;
                }
            }
        }

        // Hàm tạo ảnh
        public void TaoAnh()
        {
            // Gán các ảnh từ trong file vào các biến
            AnhO = Image.FromFile(Application.StartupPath + "\\Resources\\O.png");
            AnhX = Image.FromFile(Application.StartupPath + "\\Resources\\X.png");
        }

        // Hàm sự kiện khi bấm nút
        private void Button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            // Xác định tọa độ của nút từ tên của nút 
            // Ví dụ nút có tên button12 có tọa độ là [1, 2] 
            int hang = (button.Name[6] - '0');
            int cot = (button.Name[7] - '0');
            // Kiểm tra ô trong bảng đã dùng chưa
            if (board[hang, cot] == '\0')
            {
                // Gán giá trị của ô thành tên người chơi hiện tại
                board[hang, cot] = currentPlayer;
                // Đổi hình nền của nút tương ứng
                if (currentPlayer == 'X')
                {
                    button.BackgroundImage = AnhX;
                }
                else
                {
                    button.BackgroundImage = AnhO;
                }
                //button.Text = currentPlayer.ToString();
                // Kiểm tra xem liệu có người thắng chưa
                if (CheckWin(currentPlayer))
                {
                    // Hiển thị người thắng
                    MessageBox.Show($"Game Over! {currentPlayer} Wins!");
                    Form Form1 = new Form1();
                    Form1.Show();
                    this.Close();
                }
                // Kiểm tra xem liệu có hòa không
                else if (HetODanh())
                {
                    // Hiển thị trận đấu hòa
                    MessageBox.Show("Game Over! Tie");
                    Form Form1 = new Form1();
                    Form1.Show();
                    this.Close();
                }
                // Nếu không có người thắng hoặc hòa thì đổi người chơi 
                else
                {
                    // Đổi người chơi
                    if (currentPlayer == 'X')
                    {
                        currentPlayer = 'O';
                    }
                    else
                    {
                        currentPlayer = 'X';
                    }
                    // Nếu người chơi là O tức máy ta chạy hàm đánh ô có vị trí tốt nhất 
                    if (currentPlayer == 'O')
                    {
                        BestMove();
                    }
                }
            }
        }

        // Hàm đánh ô có vị trí tốt nhất
        private void BestMove()
        {
            // Gán giá trị tốt nhất bằng âm vô cùng
            int BestScore = int.MinValue;
            // Xét lần lượt các ô trong bảng
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Kiểm tra ô trong bảng đã dùng chưa 
                    if (board[i, j] == '\0')
                    {
                        // Gán giá trị ô thành O
                        board[i, j] = 'O';
                        // Gán giá trị điểm bằng hàm Minimax
                        int score = Minimax(board, 0, false);
                        // Xóa giá trị của ô đó
                        board[i, j] = '\0';
                        // So sánh điểm và điểm tốt nhất
                        if (score > BestScore)
                        {
                            // Thay điểm tốt nhất bằng điểm và xác định vị trí của ô có vị trí tốt nhất
                            BestScore = score;
                            hang = i;
                            cot = j;
                        }
                    }
                }
            }
            // Gán giá trị O vào bảng và nút có vị trí tốt nhất vừa tìm được
            board[hang, cot] = 'O';
            buttons[hang, cot].BackgroundImage = AnhO;
            // Kiểm tra thằng hoặc hòa
            if (CheckWin('O'))
            {
                MessageBox.Show("Game Over! O Wins!");
                Form Form1 = new Form1();
                Form1.Show();
                this.Close();
            }
            else if (HetODanh())
            {
                MessageBox.Show("Game Over! Tie");
                Form Form1 = new Form1();
                Form1.Show();
                this.Close();
            }
            // Nếu không thắng hoặc hòa thì đổi người chơi
            else
            {
                currentPlayer = 'X';
            }
        }

        // Hàm tìm giá trị Minimax
        private int Minimax(char[,] board, int depth, bool Max)
        {
            // Nếu O thắng tức máy thắng trả về giá trị 10 - độ sâu
            if (CheckWin('O'))
            {
                return 10 - depth;
            }
            // Nếu X thắng tức người thắng trả về giá trị độ sâu - 10
            if (CheckWin('X'))
            {
                return depth - 10;
            }
            // Nếu hòa trả về giá trị 0
            if (HetODanh())
            {
                return 0;
            }
            // Nếu đang xét giá trị max
            if (Max)
            {
                // Gán giá trị tốt nhất bằng âm vô cùng
                int BestScore = int.MinValue;
                // Xét lần lượt các ô trong bảng
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        // Kiểm tra ô trong bảng đã dùng chưa 
                        if (board[i, j] == '\0')
                        {
                            // Gán giá trị ô thành O
                            board[i, j] = 'O';
                            // Chạy hàm đệ quy Minimax với độ sâu tăng và xét giá trị min
                            int score = Minimax(board, depth + 1, false);
                            // Xóa giá trị của ô đó
                            board[i, j] = '\0';
                            // Điểm tốt nhất là giá trị lớn hơn trong điểm và điểm tốt nhất
                            BestScore = Math.Max(score, BestScore);
                        }
                    }
                }
                // Trả về giá trị điểm tốt nhất
                return BestScore;
            }
            // Nếu đang xét giá trị min
            else
            {
                // Gán giá trị tốt nhất bằng dương vô cùng
                int BestScore = int.MaxValue;
                // Xét lần lượt các ô trong bảng
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        // Kiểm tra ô trong bảng đã dùng chưa 
                        if (board[i, j] == '\0')
                        {
                            // Gán giá trị ô thành X
                            board[i, j] = 'X';
                            // Chạy hàm đệ quy Minimax với độ sâu tăng và xét giá trị mã
                            int score = Minimax(board, depth + 1, true);
                            // Xóa giá trị của ô đó
                            board[i, j] = '\0';
                            // Điểm tốt nhất là giá trị nhỏ hơn trong điểm và điểm tốt nhất
                            BestScore = Math.Min(score, BestScore);
                        }
                    }
                }
                // Trả về giá trị điểm tốt nhất
                return BestScore;
            }
        }

        // Kiểm tra liệu người chơi có thắng không 
        private bool CheckWin(char player)
        {
            // Kiểm tra theo hàng và côt
            for (int i = 0; i < 3; i++)
            {
                if ((board[i, 0] == player && board[i, 1] == player && board[i, 2] == player) ||
                    (board[0, i] == player && board[1, i] == player && board[2, i] == player))
                {
                    return true;
                }
            }
            // Kiểm tra theo hai đường chéo
            return (board[0, 0] == player && board[1, 1] == player && board[2, 2] == player) ||
                   (board[0, 2] == player && board[1, 1] == player && board[2, 0] == player);
        }

        // Kiểm tra liệu có hòa hay không
        private bool HetODanh()
        {
            // Xét lần lượt các ô trong bảng xem liệu có ô nào chưa sử dụng hay không
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    // Nếu có trả về không 
                    if (board[i, j] == '\0')
                    {
                        return false;
                    }
                }
            }
            // Nếu không trả về có
            return true;
        }
    }
}
